"""Metadata file to store version used by hatch.

> BE CAREFUL WITH MANUALLY CHANGING THIS FILE!

References:
    https://hatch.pypa.io/latest/version/
"""

__version__ = "0.1.0b1"
